
import React from 'react';
import FastFoodMiniApp from './components/FastFoodMiniApp';

function App() {
  return (
    <div className="App">
      <FastFoodMiniApp />
    </div>
  );
}

export default App;
